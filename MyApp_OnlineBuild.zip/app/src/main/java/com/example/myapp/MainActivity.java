package com.example.myapp;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.ViewGroup;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root;
    TextView tv(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.DKGRAY); t.setPadding(32,24,32,24); return t; }
    @Override public void onCreate(Bundle b){ super.onCreate(b); home(); }
    void home(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.addView(tv("My App",28));
        Button chat=new Button(this); chat.setText("＋ گفت‌وگوی جدید"); chat.setOnClickListener(v->chat()); root.addView(chat);
        TextView info=tv("پیام‌رسان ساده\nچت خصوصی • گروه • کانال",18); root.addView(info,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    void chat(){
        root.removeAllViews(); root.addView(tv("گفت‌وگو",24));
        EditText input=new EditText(this); input.setHint("پیام خود را بنویسید..."); root.addView(input,new LinearLayout.LayoutParams(-1,0,1));
        Button send=new Button(this); send.setText("ارسال"); send.setOnClickListener(v->{ if(input.length()>0){ Toast.makeText(this,"پیام آماده ارسال است",Toast.LENGTH_SHORT).show(); input.setText(""); }}); root.addView(send);
        Button back=new Button(this); back.setText("بازگشت"); back.setOnClickListener(v->home()); root.addView(back);
    }
}
